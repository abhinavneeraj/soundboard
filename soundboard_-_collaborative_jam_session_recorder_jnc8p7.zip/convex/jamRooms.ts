import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createRoom = mutation({
  args: {
    title: v.string(),
    bpm: v.number(),
    keySignature: v.string(),
    isPublic: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to create a room");
    }

    // Generate a unique room code
    const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();

    const jamRoomId = await ctx.db.insert("jamRooms", {
      title: args.title,
      hostId: userId,
      bpm: args.bpm,
      keySignature: args.keySignature,
      roomCode,
      isPublic: args.isPublic,
      isActive: true,
    });

    // Add host as room member
    await ctx.db.insert("roomMembers", {
      jamRoomId,
      userId,
      joinedAt: Date.now(),
      role: "host",
    });

    return jamRoomId;
  },
});

export const joinRoom = mutation({
  args: {
    roomCode: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to join a room");
    }

    const room = await ctx.db
      .query("jamRooms")
      .withIndex("by_room_code", (q) => q.eq("roomCode", args.roomCode))
      .unique();

    if (!room) {
      throw new Error("Room not found");
    }

    if (!room.isActive) {
      throw new Error("Room is no longer active");
    }

    // Check if user is already a member
    const existingMember = await ctx.db
      .query("roomMembers")
      .withIndex("by_jam_room", (q) => q.eq("jamRoomId", room._id))
      .filter((q) => q.eq(q.field("userId"), userId))
      .unique();

    if (!existingMember) {
      await ctx.db.insert("roomMembers", {
        jamRoomId: room._id,
        userId,
        joinedAt: Date.now(),
        role: "member",
      });
    }

    return room._id;
  },
});

export const getRoom = query({
  args: {
    roomId: v.id("jamRooms"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const room = await ctx.db.get(args.roomId);
    if (!room) {
      return null;
    }

    // Check if user is a member
    const membership = await ctx.db
      .query("roomMembers")
      .withIndex("by_jam_room", (q) => q.eq("jamRoomId", args.roomId))
      .filter((q) => q.eq(q.field("userId"), userId))
      .unique();

    if (!membership && !room.isPublic) {
      return null;
    }

    return room;
  },
});

export const getUserRooms = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const memberships = await ctx.db
      .query("roomMembers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const rooms = await Promise.all(
      memberships.map(async (membership) => {
        const room = await ctx.db.get(membership.jamRoomId);
        return room ? { ...room, role: membership.role } : null;
      })
    );

    return rooms.filter((room): room is NonNullable<typeof room> => room !== null);
  },
});

export const toggleRoomVisibility = mutation({
  args: {
    roomId: v.id("jamRooms"),
    isPublic: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const room = await ctx.db.get(args.roomId);
    if (!room || room.hostId !== userId) {
      throw new Error("Only the host can change room visibility");
    }

    await ctx.db.patch(args.roomId, {
      isPublic: args.isPublic,
    });
  },
});
