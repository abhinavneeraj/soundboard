import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to upload audio");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveLoop = mutation({
  args: {
    jamRoomId: v.id("jamRooms"),
    trackName: v.string(),
    audioFileId: v.id("_storage"),
    duration: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to save loops");
    }

    // Check if user is a member of the room
    const membership = await ctx.db
      .query("roomMembers")
      .withIndex("by_jam_room", (q) => q.eq("jamRoomId", args.jamRoomId))
      .filter((q) => q.eq(q.field("userId"), userId))
      .unique();

    if (!membership) {
      throw new Error("Must be a member of the room to save loops");
    }

    // Get the next order index
    const existingLoops = await ctx.db
      .query("audioLoops")
      .withIndex("by_jam_room", (q) => q.eq("jamRoomId", args.jamRoomId))
      .collect();

    const orderIndex = existingLoops.length;

    return await ctx.db.insert("audioLoops", {
      jamRoomId: args.jamRoomId,
      userId,
      trackName: args.trackName,
      audioFileId: args.audioFileId,
      orderIndex,
      duration: args.duration,
      isActive: true,
      volume: 0.8,
    });
  },
});

export const getRoomLoops = query({
  args: {
    jamRoomId: v.id("jamRooms"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const loops = await ctx.db
      .query("audioLoops")
      .withIndex("by_jam_room", (q) => q.eq("jamRoomId", args.jamRoomId))
      .collect();

    const loopsWithUrls = await Promise.all(
      loops.map(async (loop) => {
        const audioUrl = await ctx.storage.getUrl(loop.audioFileId);
        const user = await ctx.db.get(loop.userId);
        return {
          ...loop,
          audioUrl,
          userName: user?.name || user?.email || "Unknown User",
        };
      })
    );

    return loopsWithUrls.sort((a, b) => a.orderIndex - b.orderIndex);
  },
});

export const toggleLoop = mutation({
  args: {
    loopId: v.id("audioLoops"),
    isActive: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    await ctx.db.patch(args.loopId, {
      isActive: args.isActive,
    });
  },
});

export const updateLoopVolume = mutation({
  args: {
    loopId: v.id("audioLoops"),
    volume: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    await ctx.db.patch(args.loopId, {
      volume: Math.max(0, Math.min(1, args.volume)),
    });
  },
});

export const deleteLoop = mutation({
  args: {
    loopId: v.id("audioLoops"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const loop = await ctx.db.get(args.loopId);
    if (!loop) {
      throw new Error("Loop not found");
    }

    // Check if user owns the loop or is the room host
    const room = await ctx.db.get(loop.jamRoomId);
    if (loop.userId !== userId && room?.hostId !== userId) {
      throw new Error("Can only delete your own loops or if you're the host");
    }

    await ctx.db.delete(args.loopId);
  },
});
