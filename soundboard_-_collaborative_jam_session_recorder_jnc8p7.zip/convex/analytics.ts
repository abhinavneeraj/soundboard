import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const recordExport = mutation({
  args: {
    jamRoomId: v.id("jamRooms"),
    fileName: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    await ctx.db.insert("exports", {
      jamRoomId: args.jamRoomId,
      userId,
      exportedAt: Date.now(),
      fileName: args.fileName,
    });
  },
});

export const getUserAnalytics = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    // Get hosted rooms
    const hostedRooms = await ctx.db
      .query("jamRooms")
      .withIndex("by_host", (q) => q.eq("hostId", userId))
      .collect();

    // Get total loops recorded
    const totalLoops = await ctx.db
      .query("audioLoops")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    // Get total exports
    const totalExports = await ctx.db
      .query("exports")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    // Calculate average loops per session
    const roomMemberships = await ctx.db
      .query("roomMembers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const totalSessions = roomMemberships.length;
    const averageLoopsPerSession = totalSessions > 0 ? totalLoops.length / totalSessions : 0;

    return {
      totalJamRoomsHosted: hostedRooms.length,
      totalLoopsRecorded: totalLoops.length,
      totalMixdownExports: totalExports.length,
      averageLoopsPerSession: Math.round(averageLoopsPerSession * 10) / 10,
    };
  },
});
