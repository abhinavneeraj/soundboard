import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  jamRooms: defineTable({
    title: v.string(),
    hostId: v.id("users"),
    bpm: v.number(),
    keySignature: v.string(),
    roomCode: v.string(),
    isPublic: v.boolean(),
    isActive: v.boolean(),
  })
    .index("by_host", ["hostId"])
    .index("by_room_code", ["roomCode"])
    .index("by_public", ["isPublic"]),

  audioLoops: defineTable({
    jamRoomId: v.id("jamRooms"),
    userId: v.id("users"),
    trackName: v.string(),
    audioFileId: v.id("_storage"),
    orderIndex: v.number(),
    duration: v.number(),
    isActive: v.boolean(),
    volume: v.number(),
  })
    .index("by_jam_room", ["jamRoomId"])
    .index("by_user", ["userId"])
    .index("by_jam_room_and_order", ["jamRoomId", "orderIndex"]),

  roomMembers: defineTable({
    jamRoomId: v.id("jamRooms"),
    userId: v.id("users"),
    joinedAt: v.number(),
    role: v.union(v.literal("host"), v.literal("member")),
  })
    .index("by_jam_room", ["jamRoomId"])
    .index("by_user", ["userId"]),

  exports: defineTable({
    jamRoomId: v.id("jamRooms"),
    userId: v.id("users"),
    exportedAt: v.number(),
    fileName: v.string(),
  })
    .index("by_jam_room", ["jamRoomId"])
    .index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
