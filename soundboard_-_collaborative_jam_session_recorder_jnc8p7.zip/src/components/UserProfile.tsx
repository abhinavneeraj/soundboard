import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function UserProfile() {
  const user = useQuery(api.auth.loggedInUser);
  const analytics = useQuery(api.analytics.getUserAnalytics);

  if (user === undefined || analytics === undefined) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-white mb-4">Not logged in</h2>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Your Profile</h1>
        <p className="text-white/70">Track your musical journey</p>
      </div>

      {/* User Info */}
      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
        <h2 className="text-xl font-semibold text-white mb-4">Account Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <span className="text-white/70">Name:</span>
            <span className="text-white ml-2">{user.name || "Not set"}</span>
          </div>
          <div>
            <span className="text-white/70">Email:</span>
            <span className="text-white ml-2">{user.email || "Not set"}</span>
          </div>
        </div>
      </div>

      {/* Analytics */}
      {analytics && (
        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
          <h2 className="text-xl font-semibold text-white mb-4">Your Stats</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400">
                {analytics.totalJamRoomsHosted}
              </div>
              <div className="text-white/70 text-sm">Rooms Hosted</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">
                {analytics.totalLoopsRecorded}
              </div>
              <div className="text-white/70 text-sm">Loops Recorded</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400">
                {analytics.totalMixdownExports}
              </div>
              <div className="text-white/70 text-sm">Exports Created</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400">
                {analytics.averageLoopsPerSession}
              </div>
              <div className="text-white/70 text-sm">Avg Loops/Session</div>
            </div>
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
        <h2 className="text-xl font-semibold text-white mb-4">Tips for Better Jamming</h2>
        <div className="space-y-3 text-white/80">
          <div className="flex items-start gap-3">
            <span className="text-blue-400">🎵</span>
            <span>Use headphones to prevent audio feedback when recording</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-400">🎤</span>
            <span>Keep recordings under 30 seconds for better loop synchronization</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-purple-400">🎛️</span>
            <span>Adjust volume levels to create a balanced mix</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-yellow-400">🎹</span>
            <span>Pay attention to the room's BPM and key signature for harmony</span>
          </div>
        </div>
      </div>
    </div>
  );
}
