import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";

interface RoomListProps {
  onRoomSelect: (roomId: Id<"jamRooms">) => void;
}

export function RoomList({ onRoomSelect }: RoomListProps) {
  const rooms = useQuery(api.jamRooms.getUserRooms);

  if (rooms === undefined) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-2">Your Jam Rooms</h1>
        <p className="text-white/70">Click on a room to start jamming</p>
      </div>

      {rooms.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🎵</div>
          <h3 className="text-2xl font-semibold text-white mb-2">No rooms yet</h3>
          <p className="text-white/70 mb-6">Create your first jam room or join an existing one</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {rooms.map((room) => (
            <div
              key={room._id}
              onClick={() => onRoomSelect(room._id)}
              className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 hover:bg-white/20 transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-semibold text-white group-hover:text-blue-200 transition-colors">
                  {room.title}
                </h3>
                <div className="flex items-center gap-2">
                  {room.role === "host" && (
                    <span className="bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded text-xs font-medium">
                      HOST
                    </span>
                  )}
                  <span className={`w-3 h-3 rounded-full ${room.isActive ? "bg-green-400" : "bg-gray-400"}`}></span>
                </div>
              </div>
              
              <div className="space-y-2 text-sm text-white/70">
                <div className="flex justify-between">
                  <span>BPM:</span>
                  <span className="text-white">{room.bpm}</span>
                </div>
                <div className="flex justify-between">
                  <span>Key:</span>
                  <span className="text-white">{room.keySignature}</span>
                </div>
                <div className="flex justify-between">
                  <span>Room Code:</span>
                  <span className="text-white font-mono">{room.roomCode}</span>
                </div>
                <div className="flex justify-between">
                  <span>Visibility:</span>
                  <span className="text-white">{room.isPublic ? "Public" : "Private"}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
