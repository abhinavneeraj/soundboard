import { useState, useRef, useCallback } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface AudioRecorderProps {
  roomId: Id<"jamRooms">;
}

export function AudioRecorder({ roomId }: AudioRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [trackName, setTrackName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const generateUploadUrl = useMutation(api.audioLoops.generateUploadUrl);
  const saveLoop = useMutation(api.audioLoops.saveLoop);

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        } 
      });
      
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      audioChunksRef.current = [];
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.start(100); // Collect data every 100ms
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 30) {
            stopRecording();
            return 30;
          }
          return prev + 0.1;
        });
      }, 100);
      
    } catch (error) {
      toast.error("Failed to access microphone");
      console.error(error);
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  }, [isRecording]);

  const saveRecording = useCallback(async () => {
    if (audioChunksRef.current.length === 0) {
      toast.error("No recording to save");
      return;
    }

    if (!trackName.trim()) {
      toast.error("Please enter a track name");
      return;
    }

    setIsSaving(true);
    try {
      // Create audio blob
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
      
      // Get upload URL
      const uploadUrl = await generateUploadUrl();
      
      // Upload audio file
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": audioBlob.type },
        body: audioBlob,
      });
      
      if (!result.ok) {
        throw new Error("Upload failed");
      }
      
      const { storageId } = await result.json();
      
      // Save loop to database
      await saveLoop({
        jamRoomId: roomId,
        trackName: trackName.trim(),
        audioFileId: storageId,
        duration: recordingTime,
      });
      
      toast.success("Loop saved successfully!");
      setTrackName("");
      audioChunksRef.current = [];
      setRecordingTime(0);
      
    } catch (error) {
      toast.error("Failed to save recording");
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  }, [roomId, trackName, recordingTime, generateUploadUrl, saveLoop]);

  const discardRecording = useCallback(() => {
    audioChunksRef.current = [];
    setRecordingTime(0);
    setTrackName("");
  }, []);

  const hasRecording = audioChunksRef.current.length > 0 && !isRecording;

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
      <div className="space-y-4">
        {/* Recording Controls */}
        <div className="text-center">
          <div className="text-4xl font-mono text-white mb-4">
            {recordingTime.toFixed(1)}s
          </div>
          
          {!isRecording ? (
            <button
              onClick={startRecording}
              disabled={hasRecording}
              className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white font-semibold py-3 px-6 rounded-full transition-colors disabled:cursor-not-allowed"
            >
              🎤 Start Recording
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-6 rounded-full transition-colors animate-pulse"
            >
              ⏹️ Stop Recording
            </button>
          )}
          
          <div className="text-xs text-white/50 mt-2">
            Maximum recording time: 30 seconds
          </div>
        </div>

        {/* Save Recording */}
        {hasRecording && (
          <div className="space-y-4 pt-4 border-t border-white/20">
            <div>
              <label htmlFor="trackName" className="block text-sm font-medium text-white mb-2">
                Track Name
              </label>
              <input
                type="text"
                id="trackName"
                value={trackName}
                onChange={(e) => setTrackName(e.target.value)}
                className="w-full px-3 py-2 rounded bg-white/10 border border-white/20 text-white placeholder-white/50 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition-all"
                placeholder="Enter track name..."
                maxLength={50}
              />
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={saveRecording}
                disabled={isSaving || !trackName.trim()}
                className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white font-semibold py-2 px-4 rounded transition-colors disabled:cursor-not-allowed"
              >
                {isSaving ? "Saving..." : "Save Loop"}
              </button>
              <button
                onClick={discardRecording}
                disabled={isSaving}
                className="bg-gray-600 hover:bg-gray-700 disabled:bg-gray-500 text-white font-semibold py-2 px-4 rounded transition-colors disabled:cursor-not-allowed"
              >
                Discard
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
