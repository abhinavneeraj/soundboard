import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface CreateRoomProps {
  onRoomCreated: (roomId: Id<"jamRooms">) => void;
}

export function CreateRoom({ onRoomCreated }: CreateRoomProps) {
  const [title, setTitle] = useState("");
  const [bpm, setBpm] = useState(120);
  const [keySignature, setKeySignature] = useState("C Major");
  const [isPublic, setIsPublic] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  const createRoom = useMutation(api.jamRooms.createRoom);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Please enter a room title");
      return;
    }

    setIsCreating(true);
    try {
      const roomId = await createRoom({
        title: title.trim(),
        bpm,
        keySignature,
        isPublic,
      });
      toast.success("Room created successfully!");
      onRoomCreated(roomId);
    } catch (error) {
      toast.error("Failed to create room");
      console.error(error);
    } finally {
      setIsCreating(false);
    }
  };

  const keySignatures = [
    "C Major", "G Major", "D Major", "A Major", "E Major", "B Major", "F# Major",
    "C# Major", "F Major", "Bb Major", "Eb Major", "Ab Major", "Db Major", "Gb Major",
    "A Minor", "E Minor", "B Minor", "F# Minor", "C# Minor", "G# Minor", "D# Minor",
    "A# Minor", "D Minor", "G Minor", "C Minor", "F Minor", "Bb Minor", "Eb Minor"
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Create Jam Room</h1>
        <p className="text-white/70">Set up your collaborative music session</p>
      </div>

      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-white mb-2">
              Room Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition-all"
              placeholder="Enter room title..."
              maxLength={100}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="bpm" className="block text-sm font-medium text-white mb-2">
                BPM (Beats Per Minute)
              </label>
              <input
                type="number"
                id="bpm"
                value={bpm}
                onChange={(e) => setBpm(parseInt(e.target.value) || 120)}
                min="60"
                max="200"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition-all"
              />
            </div>

            <div>
              <label htmlFor="keySignature" className="block text-sm font-medium text-white mb-2">
                Key Signature
              </label>
              <select
                id="keySignature"
                value={keySignature}
                onChange={(e) => setKeySignature(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition-all"
              >
                {keySignatures.map((key) => (
                  <option key={key} value={key} className="bg-gray-800">
                    {key}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="isPublic"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
              className="w-4 h-4 text-blue-600 bg-white/10 border-white/20 rounded focus:ring-blue-500 focus:ring-2"
            />
            <label htmlFor="isPublic" className="ml-2 text-sm text-white">
              Make room public (anyone can join)
            </label>
          </div>

          <button
            type="submit"
            disabled={isCreating}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isCreating ? "Creating..." : "Create Room"}
          </button>
        </form>
      </div>
    </div>
  );
}
