import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { AudioRecorder } from "./AudioRecorder";
import { TrackMixer } from "./TrackMixer";
import { RoomSettings } from "./RoomSettings";
import { useState } from "react";

interface JamRoomProps {
  roomId: Id<"jamRooms">;
  onBack: () => void;
}

export function JamRoom({ roomId, onBack }: JamRoomProps) {
  const room = useQuery(api.jamRooms.getRoom, { roomId });
  const loops = useQuery(api.audioLoops.getRoomLoops, { jamRoomId: roomId });
  const [showSettings, setShowSettings] = useState(false);

  if (room === undefined || loops === undefined) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-white mb-4">Room not found</h2>
        <button
          onClick={onBack}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Back to Rooms
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="text-white/70 hover:text-white transition-colors"
          >
            ← Back
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white">{room.title}</h1>
            <div className="flex items-center gap-4 text-white/70 text-sm">
              <span>{room.bpm} BPM</span>
              <span>{room.keySignature}</span>
              <span className="font-mono">{room.roomCode}</span>
              <span className={`px-2 py-1 rounded text-xs ${room.isPublic ? "bg-green-500/20 text-green-300" : "bg-blue-500/20 text-blue-300"}`}>
                {room.isPublic ? "Public" : "Private"}
              </span>
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="text-white/70 hover:text-white transition-colors"
        >
          ⚙️ Settings
        </button>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <RoomSettings 
          room={room} 
          onClose={() => setShowSettings(false)} 
        />
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recording Section */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Record New Loop</h2>
          <AudioRecorder roomId={roomId} />
        </div>

        {/* Mixer Section */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Track Mixer</h2>
          <TrackMixer loops={loops} />
        </div>
      </div>
    </div>
  );
}
