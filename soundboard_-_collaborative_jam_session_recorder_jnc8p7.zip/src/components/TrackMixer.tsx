import { useState, useRef, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface Loop {
  _id: string;
  jamRoomId: string;
  trackName: string;
  userName: string;
  audioUrl: string | null;
  isActive: boolean;
  volume: number;
  duration: number;
  orderIndex: number;
}

interface TrackMixerProps {
  loops: Loop[];
}

export function TrackMixer({ loops }: TrackMixerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioElementsRef = useRef<{ [key: string]: HTMLAudioElement }>({});
  const animationFrameRef = useRef<number | undefined>(undefined);
  
  const toggleLoop = useMutation(api.audioLoops.toggleLoop);
  const updateLoopVolume = useMutation(api.audioLoops.updateLoopVolume);
  const deleteLoop = useMutation(api.audioLoops.deleteLoop);
  const recordExport = useMutation(api.analytics.recordExport);

  // Initialize audio elements
  useEffect(() => {
    loops.forEach(loop => {
      if (loop.audioUrl && !audioElementsRef.current[loop._id]) {
        const audio = new Audio(loop.audioUrl);
        audio.loop = true;
        audio.volume = loop.volume;
        audioElementsRef.current[loop._id] = audio;
      }
    });

    // Cleanup removed loops
    Object.keys(audioElementsRef.current).forEach(loopId => {
      if (!loops.find(loop => loop._id === loopId)) {
        audioElementsRef.current[loopId].pause();
        delete audioElementsRef.current[loopId];
      }
    });
  }, [loops]);

  // Update audio properties
  useEffect(() => {
    loops.forEach(loop => {
      const audio = audioElementsRef.current[loop._id];
      if (audio) {
        audio.volume = loop.volume;
        
        if (loop.isActive && isPlaying) {
          audio.play().catch(console.error);
        } else {
          audio.pause();
        }
      }
    });
  }, [loops, isPlaying]);

  // Animation frame for time updates
  useEffect(() => {
    if (isPlaying) {
      const updateTime = () => {
        setCurrentTime(prev => prev + 0.1);
        animationFrameRef.current = requestAnimationFrame(updateTime);
      };
      animationFrameRef.current = requestAnimationFrame(updateTime);
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleStop = () => {
    setIsPlaying(false);
    setCurrentTime(0);
    Object.values(audioElementsRef.current).forEach(audio => {
      audio.pause();
      audio.currentTime = 0;
    });
  };

  const handleToggleLoop = async (loopId: string, currentState: boolean) => {
    try {
      await toggleLoop({ loopId: loopId as any, isActive: !currentState });
    } catch (error) {
      toast.error("Failed to toggle loop");
    }
  };

  const handleVolumeChange = async (loopId: string, volume: number) => {
    try {
      await updateLoopVolume({ loopId: loopId as any, volume });
    } catch (error) {
      toast.error("Failed to update volume");
    }
  };

  const handleDeleteLoop = async (loopId: string) => {
    if (confirm("Are you sure you want to delete this loop?")) {
      try {
        await deleteLoop({ loopId: loopId as any });
        toast.success("Loop deleted");
      } catch (error) {
        toast.error("Failed to delete loop");
      }
    }
  };

  const handleExport = async () => {
    try {
      const activeLoops = loops.filter(loop => loop.isActive);
      if (activeLoops.length === 0) {
        toast.error("No active loops to export");
        return;
      }

      // This is a simplified export - in a real app, you'd use Web Audio API
      // to mix the tracks together and create a downloadable file
      const fileName = `jam-session-${Date.now()}.wav`;
      await recordExport({ 
        jamRoomId: loops[0]?.jamRoomId as any, 
        fileName 
      });
      
      toast.success("Export recorded! (Note: This is a demo - real export would download a mixed audio file)");
    } catch (error) {
      toast.error("Failed to export");
    }
  };

  if (loops.length === 0) {
    return (
      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20 text-center">
        <div className="text-4xl mb-4">🎵</div>
        <h3 className="text-lg font-semibold text-white mb-2">No loops yet</h3>
        <p className="text-white/70">Record your first loop to start jamming!</p>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
      {/* Transport Controls */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/20">
        <div className="flex items-center gap-4">
          <button
            onClick={handlePlayPause}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold transition-colors ${
              isPlaying 
                ? "bg-red-600 hover:bg-red-700 text-white" 
                : "bg-green-600 hover:bg-green-700 text-white"
            }`}
          >
            {isPlaying ? "⏸️" : "▶️"}
          </button>
          <button
            onClick={handleStop}
            className="w-12 h-12 rounded-full bg-gray-600 hover:bg-gray-700 text-white flex items-center justify-center text-xl transition-colors"
          >
            ⏹️
          </button>
          <div className="text-white font-mono">
            {currentTime.toFixed(1)}s
          </div>
        </div>
        
        <button
          onClick={handleExport}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors"
        >
          📥 Export Mix
        </button>
      </div>

      {/* Track List */}
      <div className="space-y-3">
        {loops.map((loop) => (
          <div
            key={loop._id}
            className={`flex items-center gap-4 p-3 rounded-lg border transition-all ${
              loop.isActive 
                ? "bg-green-500/20 border-green-500/50" 
                : "bg-white/5 border-white/10"
            }`}
          >
            {/* Toggle Button */}
            <button
              onClick={() => handleToggleLoop(loop._id, loop.isActive)}
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                loop.isActive 
                  ? "bg-green-600 text-white" 
                  : "bg-gray-600 text-white hover:bg-gray-500"
              }`}
            >
              {loop.isActive ? "🔊" : "🔇"}
            </button>

            {/* Track Info */}
            <div className="flex-1 min-w-0">
              <div className="text-white font-medium truncate">{loop.trackName}</div>
              <div className="text-white/60 text-sm">
                by {loop.userName} • {loop.duration.toFixed(1)}s
              </div>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-2">
              <span className="text-white/60 text-sm">Vol:</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={loop.volume}
                onChange={(e) => handleVolumeChange(loop._id, parseFloat(e.target.value))}
                className="w-20"
              />
              <span className="text-white/60 text-sm w-8">
                {Math.round(loop.volume * 100)}%
              </span>
            </div>

            {/* Delete Button */}
            <button
              onClick={() => handleDeleteLoop(loop._id)}
              className="text-red-400 hover:text-red-300 transition-colors"
              title="Delete loop"
            >
              🗑️
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
