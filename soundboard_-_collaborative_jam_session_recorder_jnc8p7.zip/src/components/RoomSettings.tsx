import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface Room {
  _id: string;
  title: string;
  hostId: string;
  bpm: number;
  keySignature: string;
  roomCode: string;
  isPublic: boolean;
  isActive: boolean;
}

interface RoomSettingsProps {
  room: Room;
  onClose: () => void;
}

export function RoomSettings({ room, onClose }: RoomSettingsProps) {
  const toggleRoomVisibility = useMutation(api.jamRooms.toggleRoomVisibility);

  const handleToggleVisibility = async () => {
    try {
      await toggleRoomVisibility({
        roomId: room._id as any,
        isPublic: !room.isPublic,
      });
      toast.success(`Room is now ${!room.isPublic ? "public" : "private"}`);
    } catch (error) {
      toast.error("Failed to update room visibility");
    }
  };

  const copyRoomCode = () => {
    navigator.clipboard.writeText(room.roomCode);
    toast.success("Room code copied to clipboard!");
  };

  const copyRoomLink = () => {
    const url = `${window.location.origin}?join=${room.roomCode}`;
    navigator.clipboard.writeText(url);
    toast.success("Room link copied to clipboard!");
  };

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Room Settings</h3>
        <button
          onClick={onClose}
          className="text-white/70 hover:text-white transition-colors"
        >
          ✕
        </button>
      </div>

      <div className="space-y-4">
        {/* Room Info */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-white/70">BPM:</span>
            <span className="text-white ml-2">{room.bpm}</span>
          </div>
          <div>
            <span className="text-white/70">Key:</span>
            <span className="text-white ml-2">{room.keySignature}</span>
          </div>
        </div>

        {/* Room Code */}
        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Room Code
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={room.roomCode}
              readOnly
              className="flex-1 px-3 py-2 rounded bg-white/10 border border-white/20 text-white font-mono text-center"
            />
            <button
              onClick={copyRoomCode}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded transition-colors"
            >
              Copy
            </button>
          </div>
        </div>

        {/* Share Link */}
        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Share Link
          </label>
          <button
            onClick={copyRoomLink}
            className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded transition-colors"
          >
            📋 Copy Room Link
          </button>
        </div>

        {/* Visibility Toggle */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-white font-medium">Room Visibility</span>
            <p className="text-white/60 text-sm">
              {room.isPublic ? "Anyone can join" : "Invite only"}
            </p>
          </div>
          <button
            onClick={handleToggleVisibility}
            className={`px-4 py-2 rounded font-medium transition-colors ${
              room.isPublic
                ? "bg-green-600 hover:bg-green-700 text-white"
                : "bg-gray-600 hover:bg-gray-700 text-white"
            }`}
          >
            {room.isPublic ? "Public" : "Private"}
          </button>
        </div>
      </div>
    </div>
  );
}
