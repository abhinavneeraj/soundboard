import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface JoinRoomProps {
  onRoomJoined: (roomId: Id<"jamRooms">) => void;
}

export function JoinRoom({ onRoomJoined }: JoinRoomProps) {
  const [roomCode, setRoomCode] = useState("");
  const [isJoining, setIsJoining] = useState(false);

  const joinRoom = useMutation(api.jamRooms.joinRoom);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode.trim()) {
      toast.error("Please enter a room code");
      return;
    }

    setIsJoining(true);
    try {
      const roomId = await joinRoom({
        roomCode: roomCode.trim().toUpperCase(),
      });
      toast.success("Joined room successfully!");
      onRoomJoined(roomId);
    } catch (error) {
      toast.error("Failed to join room. Check the room code and try again.");
      console.error(error);
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Join Jam Room</h1>
        <p className="text-white/70">Enter a room code to join an existing session</p>
      </div>

      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="roomCode" className="block text-sm font-medium text-white mb-2">
              Room Code
            </label>
            <input
              type="text"
              id="roomCode"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
              className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition-all text-center text-2xl font-mono tracking-widest"
              placeholder="ABC123"
              maxLength={6}
            />
            <p className="text-xs text-white/50 mt-2">
              Room codes are 6 characters long (letters and numbers)
            </p>
          </div>

          <button
            type="submit"
            disabled={isJoining || roomCode.length !== 6}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-green-700 hover:to-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isJoining ? "Joining..." : "Join Room"}
          </button>
        </form>
      </div>
    </div>
  );
}
