import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { RoomList } from "./components/RoomList";
import { JamRoom } from "./components/JamRoom";
import { CreateRoom } from "./components/CreateRoom";
import { JoinRoom } from "./components/JoinRoom";
import { UserProfile } from "./components/UserProfile";
import { Id } from "../convex/_generated/dataModel";

export default function App() {
  const [currentView, setCurrentView] = useState<"rooms" | "create" | "join" | "profile">("rooms");
  const [currentRoomId, setCurrentRoomId] = useState<Id<"jamRooms"> | null>(null);

  const handleRoomSelect = (roomId: Id<"jamRooms">) => {
    setCurrentRoomId(roomId);
    setCurrentView("rooms");
  };

  const handleBackToRooms = () => {
    setCurrentRoomId(null);
    setCurrentView("rooms");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <header className="sticky top-0 z-10 bg-black/20 backdrop-blur-sm h-16 flex justify-between items-center border-b border-white/10 shadow-lg px-4">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-white">🎵 SoundBoard</h2>
          <Authenticated>
            <nav className="flex gap-4">
              <button
                onClick={() => setCurrentView("rooms")}
                className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                  currentView === "rooms" ? "bg-white/20 text-white" : "text-white/70 hover:text-white"
                }`}
              >
                Rooms
              </button>
              <button
                onClick={() => setCurrentView("create")}
                className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                  currentView === "create" ? "bg-white/20 text-white" : "text-white/70 hover:text-white"
                }`}
              >
                Create
              </button>
              <button
                onClick={() => setCurrentView("join")}
                className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                  currentView === "join" ? "bg-white/20 text-white" : "text-white/70 hover:text-white"
                }`}
              >
                Join
              </button>
              <button
                onClick={() => setCurrentView("profile")}
                className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                  currentView === "profile" ? "bg-white/20 text-white" : "text-white/70 hover:text-white"
                }`}
              >
                Profile
              </button>
            </nav>
          </Authenticated>
        </div>
        <SignOutButton />
      </header>
      <main className="flex-1 p-6">
        <Content 
          currentView={currentView}
          currentRoomId={currentRoomId}
          onRoomSelect={handleRoomSelect}
          onBackToRooms={handleBackToRooms}
        />
      </main>
      <Toaster />
    </div>
  );
}

function Content({ 
  currentView, 
  currentRoomId, 
  onRoomSelect, 
  onBackToRooms 
}: {
  currentView: "rooms" | "create" | "join" | "profile";
  currentRoomId: Id<"jamRooms"> | null;
  onRoomSelect: (roomId: Id<"jamRooms">) => void;
  onBackToRooms: () => void;
}) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <Unauthenticated>
        <div className="text-center py-20">
          <h1 className="text-6xl font-bold text-white mb-6">
            Collaborative Jam Sessions
          </h1>
          <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            Create music together in real-time. Record loops, mix tracks, and collaborate with musicians worldwide.
          </p>
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        {currentRoomId ? (
          <JamRoom roomId={currentRoomId} onBack={onBackToRooms} />
        ) : (
          <>
            {currentView === "rooms" && <RoomList onRoomSelect={onRoomSelect} />}
            {currentView === "create" && <CreateRoom onRoomCreated={onRoomSelect} />}
            {currentView === "join" && <JoinRoom onRoomJoined={onRoomSelect} />}
            {currentView === "profile" && <UserProfile />}
          </>
        )}
      </Authenticated>
    </div>
  );
}
