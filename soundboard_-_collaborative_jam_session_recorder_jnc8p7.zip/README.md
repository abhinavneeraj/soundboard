# 🎵 SoundBoard - Collaborative Music App

A real-time collaborative music application where musicians can create jam rooms, record audio loops, and mix tracks together. Built with React, Convex, and modern web technologies.

![SoundBoard Demo](public/og-preview.png)

## ✨ Features

### 🎤 **Audio Recording**
- Record audio loops up to 30 seconds using your microphone
- High-quality audio recording with noise suppression
- Real-time recording timer and controls

### 🎛️ **Track Mixing**
- Play/pause individual loops or all tracks together
- Adjust volume levels for each track
- Real-time audio synchronization
- Export functionality (demo mode)

### 👥 **Collaborative Rooms**
- Create public or private jam rooms
- Join rooms using 6-character room codes
- Set BPM and key signature for musical harmony
- Real-time collaboration with other musicians

### 📊 **User Analytics**
- Track your musical journey with detailed stats
- Monitor rooms hosted, loops recorded, and exports created
- View average loops per session

### 🔐 **Authentication**
- Secure user authentication with username/password
- User profiles with personal statistics
- Session management

## 🚀 Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS
- **Backend**: Convex (real-time database and functions)
- **Authentication**: Convex Auth
- **Audio**: Web Audio API, MediaRecorder API
- **File Storage**: Convex Storage
- **Build Tool**: Vite
- **Styling**: Tailwind CSS with custom gradients

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/soundboard-app.git
   cd soundboard-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Convex**
   ```bash
   npx convex dev
   ```
   This will:
   - Create a new Convex project
   - Set up your database schema
   - Configure authentication

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:5173`

## 📁 Project Structure

```
soundboard-app/
├── convex/                 # Backend functions and schema
│   ├── schema.ts          # Database schema
│   ├── auth.ts            # Authentication setup
│   ├── jamRooms.ts        # Room management functions
│   ├── audioLoops.ts      # Audio recording functions
│   └── analytics.ts       # User analytics functions
├── src/
│   ├── components/        # React components
│   │   ├── AudioRecorder.tsx
│   │   ├── TrackMixer.tsx
│   │   ├── RoomList.tsx
│   │   ├── CreateRoom.tsx
│   │   ├── JoinRoom.tsx
│   │   ├── JamRoom.tsx
│   │   ├── RoomSettings.tsx
│   │   └── UserProfile.tsx
│   ├── App.tsx           # Main application component
│   └── main.tsx          # Application entry point
├── public/               # Static assets
└── package.json         # Dependencies and scripts
```

## 🎯 How to Use

### Creating a Jam Room
1. Sign up or log in to your account
2. Click "Create" in the navigation
3. Set your room title, BPM, and key signature
4. Choose public or private visibility
5. Share the room code with friends

### Recording Loops
1. Join or create a jam room
2. Click "Start Recording" to record a loop
3. Stop recording (max 30 seconds)
4. Name your track and save it
5. Your loop appears in the mixer

### Mixing Tracks
1. Use play/pause controls to start the session
2. Toggle individual loops on/off
3. Adjust volume levels for each track
4. Export your collaborative mix

### Joining Sessions
1. Get a room code from a friend
2. Click "Join" in the navigation
3. Enter the 6-character room code
4. Start jamming together!

## 🔧 Configuration

### Environment Variables
The app uses Convex for backend services. After running `npx convex dev`, your environment will be automatically configured.

### Audio Settings
- **Recording Format**: WebM with Opus codec
- **Max Recording Time**: 30 seconds
- **Audio Features**: Echo cancellation, noise suppression, auto gain control

## 🌟 Key Features Explained

### Real-time Collaboration
- Uses Convex's real-time database for instant updates
- All users see new loops and changes immediately
- Synchronized playback across all participants

### Audio Processing
- Browser-based audio recording using MediaRecorder API
- Automatic audio file upload to Convex Storage
- Efficient audio streaming and playback

### Room Management
- Unique 6-character room codes for easy sharing
- Host controls for room visibility and settings
- Member management with roles (host/member)

## 🚀 Deployment

### Deploy to Vercel
1. Push your code to GitHub
2. Connect your repository to Vercel
3. Set up your Convex environment variables
4. Deploy!

### Deploy to Netlify
1. Build the project: `npm run build`
2. Upload the `dist` folder to Netlify
3. Configure your Convex environment variables

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Convex](https://convex.dev) for real-time backend
- UI components styled with [Tailwind CSS](https://tailwindcss.com)
- Audio recording powered by Web Audio API
- Toast notifications by [Sonner](https://sonner.emilkowal.ski)

## 🐛 Known Issues

- Export functionality is currently in demo mode (shows notification only)
- Audio synchronization may vary slightly between users
- Mobile browser audio recording support varies

## 🔮 Future Enhancements

- [ ] Real audio mixing and export functionality
- [ ] MIDI instrument support
- [ ] Video chat integration
- [ ] Advanced audio effects and filters
- [ ] Mobile app versions
- [ ] Social features and user following

---

**Made with ❤️ for musicians everywhere**

Start jamming at [your-deployed-url.com](https://your-deployed-url.com)
